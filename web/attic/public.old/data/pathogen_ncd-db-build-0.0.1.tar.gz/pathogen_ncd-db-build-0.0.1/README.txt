After the Infection: A Survey of Pathogens and Non-communicable Human Disease
==============================================================================

Lape et al., medRxiv, 2023.
https://www.medrxiv.org/content/10.1101/2023.09.14.23295428v1

Database release 0.0.1, 1 September 2023
https://tf.cchmc.org/pubs/lape2023/data


Included files
--------------

  pathogen_ncd.tsv      tab-delimited text, UTF-8-encoded, no quotes
  pathogen_ncd.html     XML/HTML table fragment
  pathogen_ncd.sqlite3  SQLite 3 database

Line endings for the .tsv and .html files are those appropriate for Windows
(CR+LF) if you downloaded the .zip version; those appropriate for Linux, Mac,
or other Unix (LF) if you downloaded the .tar.gz version.


Contacts
--------

Matthew Weirauch <Matthew.Weirauch@cchmc.org>
Michael Lape <lapema@mail.uc.edu>
